#!/bin/bash

hdfs dfs -get /STEP1/in/input_data_20180215.csv
sed -e '1,2d;$d' input_data_20180215.csv | sed '$d' > test.csv
rm input_data_20180215.csv
count=$(< "test.csv" wc -l)
echo "Line count is $count" >> test.csv
hdfs dfs -put -f test.csv /STEP2/YYYY/MM/DD
#hdfs dfs -test -e /user/cloudera/STEP2/YYYY/MM/DD/SUCCESS

#retval=$?
#if [ "$retval"==0 ]; then
#	echo "IT IS THERE"
#else
#	hdfs dfs -touchz /user/cloudera/STEP2/YYYY/MM/DD/SUCCESS
#fi
